import os

def capture_svg_names():
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Output file path
    output_file = os.path.join(script_dir, "svg_filenames.txt")

    # Collect all .svg filenames in the same folder
    svg_files = [
        filename for filename in os.listdir(script_dir)
        if filename.lower().endswith(".svg") and os.path.isfile(os.path.join(script_dir, filename))
    ]

    # Write filenames to txt file
    with open(output_file, "w", encoding="utf-8") as f:
        for name in svg_files:
            f.write(name + "\n")

    print(f"Saved {len(svg_files)} SVG filenames to {output_file}")

if __name__ == "__main__":
    capture_svg_names()
